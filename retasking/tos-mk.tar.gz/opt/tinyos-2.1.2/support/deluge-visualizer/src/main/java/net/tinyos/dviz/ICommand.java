package net.tinyos.dviz;

public interface ICommand {

    String[] getCommand();

    String getErrorMatchString();

}
