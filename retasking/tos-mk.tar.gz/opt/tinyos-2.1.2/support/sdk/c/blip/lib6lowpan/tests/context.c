
#include "ip.h"

int lowpan_extern_read_context(struct in6_addr *addr, int context) {
  return 0;
}

int lowpan_extern_match_context(struct in6_addr *addr, uint8_t *ctx_id) {
  return 0;
}
