$Id: README.txt,v 1.1 2008-10-31 17:01:31 sallai Exp $

README for TestEui
Author/Contact: tinyos-help@millennium.berkeley.edu

Description:

The TestEui application prints out the IEEE EUI64 of the device periodically
using printfUART, ported to Zolertia Z1 mote.

Tools:

Any serial reader, like putty or picocom

Usage:

bauds: 115200
bits: 8
parity: none

Known bugs/limitations:

None.
 
