README for cc2420
Author/Contact: tinyos-help@millennium.berkeley.edu

Description:

This directory contains a number of test applications specific to the
TI CC2420 radio chip. See the individual test applications for more
details.

Known bugs/limitations:

None.


$Id: README.txt,v 1.1 2008-06-24 17:40:30 idgay Exp $
